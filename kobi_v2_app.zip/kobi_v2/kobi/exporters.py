from __future__ import annotations

import json


def to_markdown(record: dict) -> str:
    lines = [
        f"# KOBI Session – {record['timestamp']}",
        "",
        f"**Session:** {record['session_name']}",
        "",
        f"**Question:** {record['question']}",
        "",
        "## Prompt Setup",
        "",
        "### System Prompt",
        record.get("system_prompt") or "_None_",
        "",
        "## Model Responses",
        "",
    ]
    for row in record.get("responses", []):
        lines.extend([
            f"### {row['label']}",
            f"- Provider: {row['provider']}",
            f"- Model: {row['model']}",
            f"- Status: {'Error' if row.get('error') else 'OK'}",
            "",
        ])
        if row.get("error"):
            lines.append(f"**Error:** {row['error']}")
        else:
            lines.append(row.get("answer") or "")
        lines.append("")

    lines.extend(["## Pairwise Comparison", ""])
    if record.get("pairwise"):
        for item in record["pairwise"]:
            lines.append(
                f"- {item['Model A']} vs {item['Model B']}: {item['Assessment']} (similarity {item['Similarity']})"
            )
    else:
        lines.append("- Not enough responses yet.")
    lines.extend([
        "",
        "## Consensus Keywords",
        "",
        ", ".join(record.get("consensus_keywords") or []) or "_None_",
        "",
        "## Human Synthesis",
        "",
        record.get("synthesis") or "_No synthesis entered._",
        "",
    ])
    return "\n".join(lines)



def to_json(record: dict) -> str:
    return json.dumps(record, ensure_ascii=False, indent=2)
