from __future__ import annotations

import math
import re
from collections import Counter
from difflib import SequenceMatcher

STOPWORDS = {
    "the", "and", "for", "that", "with", "this", "from", "into", "your", "their", "they", "have",
    "will", "would", "should", "could", "about", "there", "which", "when", "what", "where", "while",
    "eine", "einer", "einem", "einen", "und", "der", "die", "das", "mit", "dass", "sind", "ist",
    "oder", "nicht", "eine", "eines", "für", "von", "auf", "als", "auch", "theory", "into",
}


def normalize(text: str) -> str:
    return " ".join((text or "").lower().split())



def similarity(a: str, b: str) -> float:
    return SequenceMatcher(None, normalize(a), normalize(b)).ratio()



def classify(score: float) -> str:
    if score >= 0.82:
        return "High overlap"
    if score >= 0.55:
        return "Moderate divergence"
    return "Strong divergence"



def pairwise(rows: list[dict]) -> list[dict]:
    filled = [r for r in rows if (r.get("answer") or "").strip()]
    out = []
    for i in range(len(filled)):
        for j in range(i + 1, len(filled)):
            left = filled[i]
            right = filled[j]
            score = round(similarity(left["answer"], right["answer"]), 2)
            out.append(
                {
                    "Model A": left["label"],
                    "Model B": right["label"],
                    "Similarity": score,
                    "Assessment": classify(score),
                }
            )
    return out



def bullets(text: str, limit: int = 4) -> list[str]:
    lines = [line.strip("-• \t") for line in (text or "").splitlines() if line.strip()]
    if len(lines) > 1:
        return lines[:limit]
    sents = [s.strip() for s in re.split(r"(?<=[.!?])\s+", text or "") if s.strip()]
    return sents[:limit]



def keywords(text: str, limit: int = 10) -> list[str]:
    words = re.findall(r"[A-Za-zÄÖÜäöüß][A-Za-zÄÖÜäöüß\-]{2,}", text or "")
    counts = Counter(w.lower() for w in words if w.lower() not in STOPWORDS)
    return [w for w, _ in counts.most_common(limit)]



def consensus_keywords(rows: list[dict], limit: int = 8) -> list[str]:
    docs = [set(keywords(r.get("answer", ""), 12)) for r in rows if (r.get("answer") or "").strip()]
    if not docs:
        return []
    counter = Counter()
    for doc in docs:
        counter.update(doc)
    need = max(2, math.ceil(len(docs) / 2))
    return [k for k, c in counter.most_common() if c >= need][:limit]
