from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Callable


@dataclass
class ProviderResult:
    provider: str
    model: str
    text: str
    error: str | None = None


class ProviderError(Exception):
    pass


def _clean(text: str | None) -> str:
    return (text or "").strip()


def call_openai(prompt: str, system_prompt: str, api_key: str | None = None, model: str = "gpt-5.4") -> ProviderResult:
    try:
        from openai import OpenAI
    except Exception as exc:  # pragma: no cover
        return ProviderResult("OpenAI", model, "", f"openai package missing: {exc}")

    key = api_key or os.getenv("OPENAI_API_KEY")
    if not key:
        return ProviderResult("OpenAI", model, "", "Missing OPENAI_API_KEY")

    try:
        client = OpenAI(api_key=key)
        response = client.responses.create(
            model=model,
            input=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt},
            ],
        )
        text = _clean(getattr(response, "output_text", ""))
        if not text:
            text = str(response)
        return ProviderResult("OpenAI", model, text)
    except Exception as exc:
        return ProviderResult("OpenAI", model, "", str(exc))



def call_anthropic(prompt: str, system_prompt: str, api_key: str | None = None, model: str = "claude-sonnet-4-5") -> ProviderResult:
    try:
        from anthropic import Anthropic
    except Exception as exc:  # pragma: no cover
        return ProviderResult("Anthropic", model, "", f"anthropic package missing: {exc}")

    key = api_key or os.getenv("ANTHROPIC_API_KEY")
    if not key:
        return ProviderResult("Anthropic", model, "", "Missing ANTHROPIC_API_KEY")

    try:
        client = Anthropic(api_key=key)
        message = client.messages.create(
            model=model,
            max_tokens=1200,
            system=system_prompt,
            messages=[{"role": "user", "content": prompt}],
        )
        parts = []
        for block in getattr(message, "content", []) or []:
            text = getattr(block, "text", None)
            if text:
                parts.append(text)
        return ProviderResult("Anthropic", model, "\n".join(parts).strip())
    except Exception as exc:
        return ProviderResult("Anthropic", model, "", str(exc))



def call_mistral(prompt: str, system_prompt: str, api_key: str | None = None, model: str = "mistral-large-latest") -> ProviderResult:
    try:
        from mistralai.client import Mistral
    except Exception as exc:  # pragma: no cover
        return ProviderResult("Mistral", model, "", f"mistralai package missing: {exc}")

    key = api_key or os.getenv("MISTRAL_API_KEY")
    if not key:
        return ProviderResult("Mistral", model, "", "Missing MISTRAL_API_KEY")

    try:
        with Mistral(api_key=key) as client:
            response = client.chat.complete(
                model=model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": prompt},
                ],
                stream=False,
                response_format={"type": "text"},
            )
        choices = getattr(response, "choices", None) or []
        text = ""
        if choices:
            message = getattr(choices[0], "message", None)
            text = getattr(message, "content", "") if message else ""
        return ProviderResult("Mistral", model, _clean(text))
    except Exception as exc:
        return ProviderResult("Mistral", model, "", str(exc))


PROVIDERS: dict[str, Callable[..., ProviderResult]] = {
    "OpenAI": call_openai,
    "Anthropic": call_anthropic,
    "Mistral": call_mistral,
}
