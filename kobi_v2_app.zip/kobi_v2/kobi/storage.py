from __future__ import annotations

import json
from pathlib import Path

DATA_DIR = Path("data")
DATA_DIR.mkdir(exist_ok=True)
SESSIONS = DATA_DIR / "sessions.jsonl"


def save_session(record: dict) -> None:
    with SESSIONS.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")



def load_sessions(limit: int = 20) -> list[dict]:
    if not SESSIONS.exists():
        return []
    rows: list[dict] = []
    with SESSIONS.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return rows[-limit:][::-1]
